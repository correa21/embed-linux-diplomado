#include <linux/module.h>
#include <linux/init.h>

static int __init first_init(void) {
	pr_info("Hello: module loaded at 0x%p\n", first_init);
	return 0;
}

static void __exit first_exit(void) {
	pr_info("Bye: module unloaded from 0x%p\n", first_exit);
}

module_init(first_init);
module_exit(first_exit);

MODULE_AUTHOR("For dummies");
MODULE_LICENSE("GPL v2");
