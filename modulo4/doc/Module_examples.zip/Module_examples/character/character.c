/*
Sample Character Driver
@*/

#include <linux/module.h> 		/* for modules */
#include <linux/fs.h> 			/* file_operations */
#include <linux/uaccess.h> 		/* copy_(to,from)_user */
#include <linux/init.h> 		/* module_init, module_exit */
#include <linux/slab.h> 		/* kmalloc */
#include <linux/cdev.h> 		/* cdev utilities */

#define DUMMY_NAME "I am a dummy"
static char *ramdisk;
#define ramdisk_size (size_t) (128*PAGE_SIZE)

static dev_t first;
static unsigned int count = 1;
static int my_major = 700, my_minor = 0;
static struct cdev *char_dev;

static int chardriver_open(struct inode *inode, struct file *file) {
pr_info(" OPENING device: %s:\n\n", DUMMY_NAME);
return 0;
}

static int chardriver_release(struct inode *inode, struct file *file) {
	pr_info(" CLOSING device: %s:\n\n", DUMMY_NAME);
	return 0;
}

static ssize_t chardriver_read(struct file *file, char __user * buf, size_t lbuf, loff_t * ppos) {
	int nbytes;
	if ((lbuf + *ppos) > ramdisk_size) {
		pr_info("aborting because this is just a stub!\n");
		return 0;
	}

	nbytes = lbuf - copy_to_user(buf, ramdisk + *ppos, lbuf);
	*ppos += nbytes;
	pr_info("\n READING function, nbytes=%d, pos=%d\n", nbytes, (int)*ppos);
	return nbytes;
}

static ssize_t chardriver_write(struct file *file, const char __user * buf, size_t lbuf, loff_t * ppos) {
	int nbytes;
	if ((lbuf + *ppos) > ramdisk_size) {
		pr_info("aborting because this is just a stub!\n");
		return 0;
	}
	nbytes = lbuf - copy_from_user(ramdisk + *ppos, buf, lbuf);
	*ppos += nbytes;
	pr_info("\n WRITING function, nbytes=%d, pos=%d\n", nbytes, (int)*ppos);
	return nbytes;
}

static const struct file_operations chardriver_fops = {
	.owner = THIS_MODULE,
	.read = chardriver_read,
	.write = chardriver_write,
	.open = chardriver_open,
	.release = chardriver_release,
};

static int __init my_init(void) {
	ramdisk = kmalloc(ramdisk_size, GFP_KERNEL);
	first = MKDEV(my_major, my_minor);
	register_chrdev_region(first, count, DUMMY_NAME);
	char_dev = cdev_alloc();
	cdev_init(char_dev, &chardriver_fops);
	cdev_add(char_dev, first, count);
	pr_info("\n Succeeded in registering a character device %s\n", DUMMY_NAME);
	return 0;
}

static void __exit my_exit(void) {
	cdev_del(char_dev);
	unregister_chrdev_region(first, count);
	pr_info("\ndevice unregistered\n");
	kfree(ramdisk);
}

module_init(my_init);
module_exit(my_exit);
MODULE_AUTHOR("For dummies based on Jerry Cooperstein work");
MODULE_LICENSE("GPL v2");